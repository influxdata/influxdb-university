# Assessment to run before the course start

### Q What are the characteristics of a time-serie (multichoice)
- all time-stamped data
- data are generated with regular time periods
- the volume of data is huge
- the variety of data is high 

### Q Why do we need time-series databases (all true, little marketing)
- because data ingestion is critical for data-intensive applications
- because temporal queries the center of analytics
- because continuous queries enable real-time analytics

## InfluxDB Basics

### What is the Line Protocol?
- the data format used for data ingestion into influxdb
- a communication protocol between Telegraf and influxDB
- an extension of AVRO for time-series serialization.

### What is telegraf
- a plugin-based server agent that can collect metrics from a wide variety of sources
- a influxdb plugin for data ingestion
- a source in flux

## In the following line-protocol lines, can you identify

```
AiQ,city=London,continent=Europe,nation=UK co2=16i,no2=896i,o3=403i,pm=356i,so2=1266i 1590741724944
AiQ,city=Milan,continent=Europe,nation=Italy co2=23i,no2=1138i,o3=566i,pm=33i,so2=391i 1590741731846
AiQ,city=Liverpool,continent=Europe,nation=UK co2=10i,no2=1182i,o3=2i,pm=146i,so2=1446i 1590741731946
```

### the tags values

- A: co2,pm, nation, AiQ
- B: Europe,Italy,Milan,UK,London,Liverpool
- C: continent, nation, city

### the fields names

- A: AiQ
- B: o3, no2, pm, so2,co2
- C: continent, AiQ, city
- D: integer, float, long

### the timestamp and the measurement

1590741731946, 1590741731846, 1590741731946
AIQ

##  Time-Series

## How would you describe the two time-series in figure
![](./synch.pdf)

### S1 and S2 
- A: are not synchronized: metrics don’t occur at the same time and rate
- C: are synchronized: metrics occur at the same time and rate
- D: are not synchronized: some metrics now occur at the same time, but the rate is different

answer: A

### S2 and S3
- A are not synchronized: some metrics now occur at the same time, but the rate is different
- B are not synchronized: metrics don’t occur at the same time and rate
- C are synchronized: metrics occur at the same time and rate

answer :B

## In Stream Processing, windows are a very important abstraction because:
- A: they allows to deal with infinite nature of data stream
- B: they regularize the stream rate making the processing predictable
- C: they enable reduce the memory consumption of aggregates over streams

### In Time-Series DB, windows are a very important abstraction because:
- A: they allows to deal with infinite nature of data stream
- B: they regularize the stream rate making the processing predictable
- C: they enable reduce the memory consumption of aggregates over streams

## Functional programming experience 

Which ones of the following are high-order functions:

- A: map
- B: reduce
- C: group
- D: filter

answer: A and D


